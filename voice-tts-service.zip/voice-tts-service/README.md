# voice-tts-service

A serverless microservice that converts text to speech using ElevenLabs and uploads the audio file to Amazon S3.

### Endpoint

POST `/api/generate-tts`

### Environment Variables

Copy `.env.example` and fill in your actual credentials.
